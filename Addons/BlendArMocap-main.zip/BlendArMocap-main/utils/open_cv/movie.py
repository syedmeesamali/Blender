import cv2


class Movie(object):
    path = ""
    cap = cv2.VideoCapture(path)
