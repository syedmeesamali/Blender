# Array tools

## Description
Array tools is an addon for Blender 2.80+ to create translation, scale, rotation array with offset or global parameters in any direction and mix them.


## Installation

(remove any previous version)

* download the files (download zip)

* save the zip file

* in Blender, go to edit > user preferences > add-ons > install... and select the zip file

* check the array_tools tab


## Instructions
See [english wiki](https://github.com/Elreenys/array_tools/wiki/Home_eng) or [french wiki](https://github.com/Elreenys/array_tools/wiki/Home_fr).


## Authors

- **Elreenys** 


## License

This project is licensed under the GPL 3 License.
